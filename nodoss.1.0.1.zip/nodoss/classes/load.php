<?php defined('ABSPATH') or die('Sorry dude!');
/**
 * @package       NoDoss
 * @author        Edwin Bekedam
 * @license       gplv2
 * @version       1.0.1
 *
 * @wordpress-plugin
 */

/** Nodoss Security headers */
require_once plugin_dir_path(dirname(__FILE__)) . '/inc/init/http-headers.php'; 
/** Bullet proof sitemaps */
require_once plugin_dir_path(dirname(__FILE__)) . '/inc/class-wp-bulletproof-sitemaps.php';
/** Load csrf protection  */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-csrf.php';
/** Load WP No Pingback  */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-disable-pingback.php';
/** Load floating PHP Host injection protection */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-floatingpoint-php-injection.php';
/** Load Nodoss WP Heartbeat */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-heartbeat.php';
/** Load HTTPS Secure  Protocol */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-https.php';
/** Load Sameorigin Iframe-buster */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-sameorigin.php';
/** WP Update Privacy */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-update-privacy.php';
/** User agent DarknetSpam */
require_once plugin_dir_path(dirname(__FILE__)) . '/inc/class-wp-user-agent.php';
/** Stop from modifying WordPress */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-user-edits.php';
/** Limit wp user reset api */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-user-reset-api.php';
/** Load Xpowered-by */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-x-powered-by.php';