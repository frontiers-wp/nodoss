<?php // Content-Security-Policy: upgrade-insecure-requests
function nodoss_upgrade_insecure_requests_csp_headers() {
    header( 'Content-Security-Policy: upgrade-insecure-requests'); 
}
add_action( 'send_headers', 'nodoss_upgrade_insecure_requests_csp_headers' );