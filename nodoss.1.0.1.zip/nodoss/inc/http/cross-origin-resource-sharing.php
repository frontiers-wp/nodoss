<?php
/**
 * Add HTTPS cors Headers
 */
function nodoss_add_cors_headers() {
    /** Access-Control-Allow-Headers: X-Custom-Header */
    header("Access-Control-Allow-Headers: X-Custom-Header, Upgrade-Insecure-Requests");
    /** Access-Control-Allow-Methods: GET, POST, OPTIONS */
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
    /** Access-Control-Allow-Headers: Content-Type, Authorization */
    header("Access-Control-Allow-Headers: Authorization, Content-Type");
    /** Access-Control-Allow-Origin: */
    Header("Access-Control-Allow-Origin: <origin>");
    /** Access-Control-Expose-Headers: Content-Length, X-My-Custom-Header */
    header("Access-Control-Expose-Headers: Content-Length, X-JSON");
    /** Access-Control-Allow-Credentials' 'true'; */
    header("Access-Control-Allow-Credentials: true ");
    /** Access-Control-Max-Age: 86400 */
    header("Access-Control-Max-Age: 86400");
}
add_action( 'send_headers', 'nodoss_add_cors_headers' );