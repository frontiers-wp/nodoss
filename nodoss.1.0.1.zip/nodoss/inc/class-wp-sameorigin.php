<?php
/**
 * Nodoss blank target vulnerability
 */
require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-blank-target-vulnerability.php';

/**
 * "SAMEORIGIN" always; Do NOT Iframe me.
 */
add_action('template_redirect', 'dos_not_iframe_me');

function dos_not_iframe_me() {
    send_frame_options_header();
}

if (!function_exists('send_frame_options_header')) {
    function send_frame_options_header() {
        @header('X-Frame-Options: SAMEORIGIN');  // "SAMEORIGIN" always;
    }
}

/**
 * Break Out of Frames for WordPress.
 */
function NoDoss_wp_break_out_of_frames() {
    if (!is_preview() && !is_customize_preview()) {
        echo "\n<script type=\"text/javascript\">";
        echo "\n<!--";
        echo "\nif (parent.frames.length > 0) { parent.location.href = location.href; }";
        echo "\n-->";
        echo "\n</script>\n\n";
    }
}
add_action('wp_head', 'NoDoss_wp_break_out_of_frames');


/**
 * Prevents the site from being displayed within an iframe (iframe buster)
 * by adding inline JavaScript to the 'nodoss-iframe-buster' script handle.
 */
function nodoss_prevent_iframe_embed() {
    // JavaScript code to bust out of iframes
    $iframe_buster_js = '
        if (self == top) {
            var theBody = document.getElementsByTagName("body")[0];
            theBody.style.display = "block";
        } else {
            top.location = self.location;
        }
    ';

    // Add the inline script to WordPress
    wp_add_inline_script('nodoss-iframe-buster', $iframe_buster_js);
}

// Hook into WordPress script enqueue
add_action('wp_enqueue_scripts', 'nodoss_prevent_iframe_embed');