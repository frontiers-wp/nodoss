<?php

class NoDossXPoweredBy
{
    /**
     * Constructor - Secures server headers and disables potentially sensitive information
     */
    public function __construct()
    {
        $this->NoDossXPoweredBy();
    }

    /**
     * Secures server headers by removing or disabling sensitive information
     */
    private function NoDossXPoweredBy()
    {
        // Remove X-Powered-By header if possible
        if (function_exists('header_remove')) {
            header_remove('X-Powered-By');
        } else {
            // Alternative approach when header_remove is not available
            $this->setPhpIniDirectives();
        }
    }

    /**
     * Sets PHP ini directives for security when header_remove is unavailable
     */
    private function setPhpIniDirectives()
    {
        // Disable PHP version exposure
        if (ini_get('expose_php') !== '0') {
            ini_set('expose_php', '0');
            // Fallback if ini_set fails (though this won't actually change the setting)
            if (!defined('EXPOSE_PHP_FALLBACK')) {
                define('EXPOSE_PHP_FALLBACK', '0');
            }
        }

        // Note: 'Options -Indexes' is an Apache directive and cannot be set via ini_set
        // This should be configured in .htaccess or server config instead
    }

    /**
     * Hides FastCGI headers if the function exists
     */
    public function hideFastcgiHeader()
    {
        if (function_exists('fastcgi_hide_header')) {
            fastcgi_hide_header(0);
        }
    }
}