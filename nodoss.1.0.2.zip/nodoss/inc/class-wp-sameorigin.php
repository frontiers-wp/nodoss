<?php
/**
 * NoDoss Same-Origin Frame Protection
 *
 * Prevents clickjacking and iframe embedding from different origins
 */
class NoDossSameOriginFrame
{
    /**
     * Initialize the class
     */
    public function __construct()
    {
        $this->load_dependencies();
        $this->setup_hooks();
    }

    /**
     * Load required dependencies
     */
    private function load_dependencies()
    {
        require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-blank-target-vulnerability.php';
    }

    /**
     * Setup WordPress hooks
     */
    private function setup_hooks()
    {
        // Send X-Frame-Options header
        add_action('template_redirect', [$this, 'send_frame_options_header']);

        // Break out of frames (legacy method)
        add_action('wp_head', [$this, 'break_out_of_frames']);

        // Modern iframe buster
        add_action('wp_enqueue_scripts', [$this, 'prevent_iframe_embed']);
    }

    /**
     * Send X-Frame-Options header to prevent clickjacking
     */
    public function send_frame_options_header()
    {
        @header('X-Frame-Options: SAMEORIGIN');
    }

    /**
     * Legacy method to break out of frames using JavaScript
     */
    public function break_out_of_frames()
    {
        if (!is_preview() && !is_customize_preview()) {
        echo "\n<script type=\"text/javascript\">";
        echo "\n<!--";
        echo "\nif (parent.frames.length > 0) { parent.location.href = location.href; }";
        echo "\n-->";
        echo "\n</script>\n\n";
        }
    }

    /**
     * Modern iframe buster using WordPress script handling
     */
    public function prevent_iframe_embed()
    {
        $iframe_buster_js = '
            if (self == top) {
                var theBody = document.getElementsByTagName("body")[0];
                theBody.style.display = "block";
            } else {
                top.location = self.location;
            }
        ';

        wp_add_inline_script('nodoss-iframe-buster', $iframe_buster_js);
    }
}

// Initialize the class
new NoDossSameOriginFrame();
