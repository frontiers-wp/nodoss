// Prevent the page from being embedded in an iframe (frame-busting)
(function() {
    'use strict';

    // Method 1: Check if current window is the top window
    if (window.self === window.top) {
        const body = document.getElementsByTagName('body')[0];
        if (body) {
            body.style.display = 'block';
        }
    } else {
        window.top.location.replace(window.self.location.href);
    }

    // Method 2: Check if current window is inside a frameset
    if (window.parent.frames.length > 0) {
        window.top.location.replace(window.location.href);
    }

    // Method 3: Additional check for top window (redundant but kept for thoroughness)
    if (window.top !== window.self) {
        window.top.location.href = window.self.location.href;
    }
})();