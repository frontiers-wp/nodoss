<?php
/**
 * @package       NoDoss
 * @author        Edwin Bekedam
 * @license       gplv2
 * @version       1.0.5
 *
 * @wordpress-plugin
 */
if (!defined('ABSPATH')) die();

foreach( glob( plugin_dir_path( __FILE__ )."http/*.php" ) as $file ){
	include_once $file;
}

require_once plugin_dir_path(dirname(__FILE__)) . 'http/cross-origin-policy.php';
require_once plugin_dir_path(dirname(__FILE__)) . 'http/cross-origin-resource-sharing.php';
require_once plugin_dir_path(dirname(__FILE__)) . 'http/csp-upgrade-insecure-requests.php';
require_once plugin_dir_path(dirname(__FILE__)) . 'http/referrer-policy.php';
require_once plugin_dir_path(dirname(__FILE__)) . 'http/x-content-type-options.php';
require_once plugin_dir_path(dirname(__FILE__)) . 'http/x-permitted-cross-domain-policies.php';
