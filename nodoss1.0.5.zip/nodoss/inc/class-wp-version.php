<?php
/**
 * Removes WordPress version from the generator meta tag and global $wp_version.
 *
 * @package Nodoss\Frontiers\Security
 */
namespace Nodoss\Frontiers\Security;

if (!defined('ABSPATH')) die();
/**
 * Removes the WordPress version from the generator meta tag.
 *
 * @return string Empty string to suppress version output.
 */
function remove_wordpress_version(): string
{
    return '';
}

/**
 * Initializes the version removal hooks.
 */
function initialize_version_removal()
{
    // Remove version from meta generator tag.
    add_filter('the_generator', __NAMESPACE__ . '\\remove_wordpress_version');

    // Remove version from global $wp_version (if accessible).
    if (isset($GLOBALS['wp_version'])) {
        unset($GLOBALS['wp_version']);
    }
}

// Execute initialization.
initialize_version_removal();