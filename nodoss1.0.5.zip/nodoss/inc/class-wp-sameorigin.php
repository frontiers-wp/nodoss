<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * NoDoss Same-Origin Frame Protection
 *
 * Prevents clickjacking and iframe embedding from different origins
 */
class WpFtNoDossSameOriginFrame
{
    /**
     * Initialize the class
     */
    public function __construct()
    {
        $this->setup_hooks();
    }

    /**
     * Setup WordPress hooks
     */
    private function setup_hooks()
    {
        // Send X-Frame-Options header
        add_action('template_redirect', [$this, 'nodoss_send_frame_options_header']);
        
        // Modern iframe buster
        add_action('wp_enqueue_scripts', [$this, 'nodoss_prevent_iframe_embed'], 10);

        // Blank target vulnerability WordPress
        add_action('wp_enqueue_scripts', [$this, 'nodoss_blank_target_vulnerability'], 10);
        
        // Enqueue same as orgin.
        add_action('wp_head', [$this, 'nodoss_inject_co_noright_css'], 20);
    }

    /**
     * Send X-Frame-Options header to prevent clickjacking
     */
    public function nodoss_send_frame_options_header()
    {
        header('X-Frame-Options: SAMEORIGIN');
    }
    
    /**
     * URL script handling
     */
    public function get_url_to_asset($script)
    {
        return plugins_url($script, __FILE__);
    }
    
    /**
     * Modern iframe buster using WordPress script handling
     */
    public function nodoss_prevent_iframe_embed()
    {
        // Register the iframe buster script
        wp_register_script(
            'nodoss-prevent-iframe-embed',
            'assets/js/js/same.origin.frame.js',
            '', [], '', true
        );
        
        wp_localize_script( 'nodoss-prevent-iframe-embed', 'php_vars', array( 'php_vars', $data ) );
        $inline_script = 'console.log(php_vars.name); console.log(php_vars.age);';
        wp_add_inline_script('nodoss-prevent-iframe-embed', $data, $script );

    }
    
    /**
     * Blank target vulnerability WordPress
     */
    public function nodoss_blank_target_vulnerability()
    {
        // Register Blank target vulnerability script
        wp_register_script(
            'nodoss-blank-target-vulnerability',
            'assets/js/js/blank.target.vulnerability.js',
            '', [], '', true
        );

        wp_localize_script( 'nodoss-blank-target-vulnerability', 'php_vars', array( 'php_vars', $data ) );
        $inline_script = 'console.log(php_vars.name); console.log(php_vars.age);';
        wp_add_inline_script('nodoss-blank-target-vulnerability', $data, $script );
    }

    /**
     * CSS rules for hiding author elements
     *
     * @var array
     */
    private const NODOSS_WPFT_CSS_RULES = [
        'body{--window-open:true}',
        '.window-opened{--window-opener:null}',
        'body{user-select:none!important;-webkit-user-select:none!important;-moz-user-select:none!important;-ms-user-select:none!important;pointer-events:none!important}',
    ];

    /**
     * Inject CSS to hide author elements
     */
    public function nodoss_inject_co_noright_css() {
        $style = '<style>';
        foreach (self::NODOSS_WPFT_CSS_RULES as $selector => $rule) {
            $style .= sprintf(
                '%s {%s} ',
                esc_html($selector),
                esc_html($rule)
            );
        }
        $style .= '</style>';

        echo wp_kses($style, ['style' => []]);
    }

}

// Initialize the class
new WpFtNoDossSameOriginFrame();