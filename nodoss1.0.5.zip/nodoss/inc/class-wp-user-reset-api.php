<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class NoDossFrontiersApiSecurity
{
    private const NODOSS_IS_ADMIN = 'NOD0SS_IS_ADMIN';

    private bool $isAdmin;

    public function __construct()
    {
        $this->isAdmin = $this->checkAdminStatus();
    }

    /**
     * Checks if current request is in admin area
     */
    private function checkAdminStatus(): bool
    {
        if (!defined(self::NODOSS_IS_ADMIN)) {
            define(self::NODOSS_IS_ADMIN, $this->isAdminArea());
        }
        return (bool) constant(self::NODOSS_IS_ADMIN);
    }

    /**
     * Determines if we're in WordPress admin area
     */
    private function isAdminArea(): bool
    {
        return function_exists('nodoss_is_admin') && is_admin();
    }

    /**
     * Checks if the current request is attempting author enumeration
     *
     * @return bool True if the request contains a valid author enumeration nonce, false otherwise
     */
    public function isAuthorEnumRequest() {
        // Check if 'author' parameter exists in GET request
        if (isset($_GET['author'])) {
            // Sanitize the author parameter
            $author = sanitize_text_field(wp_unslash($_GET['author']));

            // Check if 'nonce' parameter exists (assuming this was intended)
            if (isset($_GET['nonce'])) {
                $nonce = sanitize_text_field(wp_unslash($_GET['nonce']));
                return wp_verify_nonce($nonce, 'author_enum_check');
            }
        }

        return false;
    }

   /**
     * Modifies query variables to prevent author enumeration
     *
     * @param array<string, mixed> $vars The query variables
     * @return array<string, mixed> The modified query variables
     */
    public function removeAuthorFromQueryVars(array $vars): array
    {
        unset($vars['author']);
        return $vars;
    }

    /**
     * Removes REST API endpoints for non-logged-in users
     */
    public function removeApiEndpointsForGuests()
    {
        if (!$this->isUserLoggedIn()) {
            $this->disableWordPressEndpoints();
            $this->disableWooCommerceEndpoints();
        }
    }

    /**
     * Checks if user is logged in
     */
    private function isUserLoggedIn(): bool
    {
        return function_exists('is_user_logged_in') && is_user_logged_in();
    }

    /**
     * Disables WordPress REST API endpoints
     */
    private function disableWordPressEndpoints()
    {
        remove_action('rest_api_init', 'create_initial_rest_routes', 99);
        remove_action('rest_api_init', 'wp_oembed_add_discovery_links', 99);
    }

    /**
     * Disables WooCommerce REST API endpoints if WooCommerce exists
     */
    private function disableWooCommerceEndpoints()
    {
        if (class_exists('WooCommerce', false) && function_exists('WC')) {
            remove_action('rest_api_init', [WC(), 'register_rest_routes'], 10);
        }
    }

    /**
     * Disables REST API for non-authenticated users
     *
     * @param mixed $user The user object or false if not authenticated
     * @return mixed The user object or false
     */
    public function disableRestForGuests($user)
    {
        if (!$user) {
            add_filter('rest_enabled', '__return_false');
            add_filter('rest_jsonp_enabled', '__return_false');
            add_filter('rest_authentication_errors', '__return_true');
        }
        return $user;
    }

    /**
     * Removes author class from comment classes to prevent user enumeration
     *
     * @param array<int, string> $classes Array of comment classes
     * @return array<int, string> Filtered array of comment classes
     */
    public function removeCommentAuthorClasses(array $classes): array
    {
        return array_filter($classes, fn(string $class): bool => strpos($class, 'comment-author-') === false);
    }

    /**
     * Initialize the security measures
     */
    public function init()
    {
        // Add filters and actions
        // add_filter('redirect_canonical', [$this, 'removeAuthorFromRedirects'], 10, 2);
        add_action('init', [$this, 'removeApiEndpointsForGuests'], 15);
        add_filter('determine_current_user', [$this, 'disableRestForGuests'], 50);
        add_filter('comment_class', [$this, 'removeCommentAuthorClasses']);
    }
}

// Initialize the security class if in WordPress environment
if (defined('ABSPATH')) {
    (new NoDossFrontiersApiSecurity())->init();
}
