<?php /** Prevent MIME-Type Sniffing */
function nodoss_x_content_type_nosniff_headers() {
    header( 'X-Content-Type-Options: nosniff ');
}
add_action( 'send_headers', 'nodoss_x_content_type_nosniff_headers' );