<?php defined('ABSPATH') or die('Sorry dude!');
/**
 * QUICK FIX Heartbeat
 */
add_action( 'admin_init', function() {
   register_setting( 'general', 'nodoss_aj_heartbeat_interval', 'intval' );
   add_settings_field( 'nodoss__aj_heartbeat_interval', 'Heartbeat Interval', function() {
       $interval = get_option( 'nodoss_aj_heartbeat_interval', 240 );
       echo "<input type='number' name='nodoss_aj_heartbeat_interval' value='".absint($interval)."' min='15' max='240' /> seconds";
   }, 'general' );
});
 
add_filter( 'heartbeat_settings', function( $settings ) {
   $settings['interval'] = get_option( 'nodoss_aj_heartbeat_interval', 240 );
   return $settings;
});
