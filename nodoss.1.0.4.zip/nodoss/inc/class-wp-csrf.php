<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Remove website field from comment form
 * Remove URL field from WordPress comment form
 * @param array $fields The default comment form fields
 * @return array Modified comment form fields
 */
add_filter('comment_form_field_url', '__return_false');

/**
 * WordPress Comment Form Security Enhancements
 */
$comment_form_modifications = [
    // Remove URL field using WordPress filter
    'comment_form_field_url' => '__return_false',

    // Custom filter to remove website field
    'comment_form_default_fields' => function(array $fields): array {
        if (isset($fields['url'])) {
            unset($fields['url']);
        }
        return $fields;
    }
];

foreach ($comment_form_modifications as $filter => $callback) {
    add_filter($filter, $callback);
}

/**
 * Generate and add CSRF tokens to the comment form
 *
 * Creates a secure CSRF token by combining a WordPress nonce
 * with a cryptographically secure random value, then signs it with HMAC-SHA256.
 */
function add_comment_form_csrf()
{
    // Generate a WordPress nonce
    $wp_nonce = wp_create_nonce('comment_form_csrf');

    // Generate a secure random token
    $random_bytes = random_bytes(32);
    $build_id = 'comment-form-csrf-' . base64_encode($random_bytes);

    // Create the CSRF token
    $key = defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : '';
    $data = $build_id . $wp_nonce;
    $signature = hash_hmac('sha256', $data, $key, true);
    $csrf_token = base64_encode($signature);

    // Output the hidden fields with proper escaping
    echo sprintf(
        '<input type="hidden" name="build_id" value="%s">' .
        '<input type="hidden" name="wp_nonce" value="%s">' .
        '<input type="hidden" name="csrf_token" value="%s">',
        esc_attr($build_id),
        esc_attr($wp_nonce),
        esc_attr($csrf_token)
    );
}

/**
 * Validate CSRF tokens when a comment is submitted
 *
 * @param array $form_data The submitted form data
 * @return bool True if validation passes, false otherwise
 */
function validate_comment_csrf(array $form_data): bool
{
    // Check if all required fields are present
    $required_fields = ['build_id', 'wp_nonce', 'csrf_token'];
    foreach ($required_fields as $field) {
        if (!isset($form_data[$field])) {
            return false;
        }
    }

    // Check if the build_id has the correct prefix
    if (strpos($form_data['build_id'], 'comment-form-csrf-') !== 0) {
        return false;
    }

    // Verify the WordPress nonce
    if (!wp_verify_nonce($form_data['wp_nonce'], 'comment_form_csrf')) {
        return false;
    }

    // Verify the CSRF token
    $key = defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : '';
    $data = $form_data['build_id'] . $form_data['wp_nonce'];
    $signature = hash_hmac('sha256', $data, $key, true);
    $expected_token = base64_encode($signature);

    return hash_equals($expected_token, $form_data['csrf_token']);
}

// Add CSRF tokens to the form
add_action('comment_form_after_fields', 'add_comment_form_csrf');

// Validate CSRF tokens when the form is submitted
add_action('pre_comment_on_post', function (int $comment_post_ID): void {
    // Sanitize and validate input
    $form_data = filter_input_array(INPUT_POST, [
        'build_id' => FILTER_SANITIZE_STRING,
        'wp_nonce' => FILTER_SANITIZE_STRING,
        'csrf_token' => FILTER_SANITIZE_STRING
    ]);

    if (!$form_data) {
        wp_die('Invalid form submission. Please try again.');
    }

    // Validate the CSRF tokens
    if (!validate_comment_csrf($form_data)) {
        wp_die('Comment submission failed due to security validation failures. Please refresh the page and try again.');
    }
});