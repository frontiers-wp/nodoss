<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class NoDossXPoweredBy
{
    /**
     * Constructor - Secures server headers and disables potentially sensitive information
     */
    public function __construct()
    {
        $this->NoDossXPoweredBy();
    }

    /**
     * Secures server headers by removing or disabling sensitive information
     */
    private function NoDossXPoweredBy()
    {
        // Remove X-Powered-By header if possible
        if (function_exists('header_remove')) {
            header_remove('X-Powered-By');
        } else {
            // Alternative approach when header_remove is not available
            $this->setPhpIniDirectives();
        }
    }

    /**
     * Sets PHP ini directives for security when header_remove is unavailable
     */
    private function setPhpIniDirectives()
    {
        // Disable PHP version exposure
        if (!defined('EXPOSE_PHP_FALLBACK')) {
            define('EXPOSE_PHP_FALLBACK', '0');
        }
        
    }

    /**
     * Hides FastCGI headers if the function exists
     */
    public function hideFastcgiHeader()
    {
        if (function_exists('fastcgi_hide_header')) {
            fastcgi_hide_header(0);
        }
    }
}