<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Secure HTTPS Headers and Utilities
 */
class NoDossFrontiersSecHttps
{
    /**
     * Check if the connection is secure and redirect if needed
     *
     * @param string $host   The host name
     * @param string $uri    The request URI
     * @param bool   $secure Whether the connection is secure
     */
    public static function check(string $host, string $uri, bool $secure)
    {
        if ($secure) {
            // Set Content-Security-Policy header for secure connections
            header('Content-Security-Policy: upgrade-insecure-requests');
        } else {
            // Redirect to HTTPS if not secure
            $redirect = 'https://' . $host . $uri;
            header('HTTP/1.1 301 Moved Permanently');
            header('Location: ' . $redirect);
            exit();
        }
    }

    /**
     * Modify headers for secure content
     *
     * @param array $headers Current headers array
     * @return array Modified headers with security headers
     */
    public static function modifyHeaders(array $headers = []): array
    {
        return array_merge($headers, [
            'Content-Security-Policy' => 'upgrade-insecure-requests',
            'X-Content-Type-Options'  => 'nosniff',
            'X-Frame-Options'         => 'SAMEORIGIN',
            'Referrer-Policy'         => 'strict-origin-when-cross-origin'
        ]);
    }
}

/**
 * Convert a URL to HTTPS
 *
 * @param string $url The URL to convert
 * @return string The HTTPS URL
 */
function nodoss_convert_to_https(string $url): string
{
    return preg_replace('/^http(?=:\/\/)/i', 'https', $url);
}

/**
 * Pre-process input for XSS detection
 *
 * @param string $input The input to process
 * @return string The processed input
 */
function nodoss_pre_process_all_imput(string $input): string
{
    return html_entity_decode(strip_all_tags($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Set the HSTS header
 */
function nodoss_sec_hsts_header()
{
    // 2 years in seconds (63072000)
    $maxAge = 63072000;

    header(
        sprintf(
            'Strict-Transport-Security: max-age=%d; includeSubDomains; preload;',
            $maxAge
        )
    );
}
add_action('send_headers', 'nodoss_sec_hsts_header');

/**
 * Add security headers
 */
function nodoss_add_security_headers()
{
    if (is_admin()) {
        header('X-XSS-Protection: 0');
        header('X-UA-Compatible: IE=edge');
    }
}
add_action('init', 'nodoss_add_security_headers');


/**
 * Detect XSS in input
 *
 * @param string $input The input to check
 * @return string The sanitized input
 */
function nodoss_detect_xss(string $input): string
{
    $input = nodoss_pre_process_input($input);

    // Common XSS patterns to detect
    $patterns = [
        '/<[^\w<>]*(?:[^<>"\'\s]*:)?[^\w<>]*(?:\W*s\W*c\W*r\W*i\W*p\W*t|\W*f\W*o\W*r\W*m)/i',
        '/(?:<\w[\s\S]*[\s\0\/]|[\'"])(?:on\w+\s*=?|javascript|vbscript|expression)/i',
        '/(?:<\w[\s\S]*[\s\0\/]|[\'"])(?:formaction|style|background|src|lowsrc|ping)/i'
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $input)) {
            // Log attempt or take other action here
            return '';
        }
    }

    return $input;
}

/**
 * Check for header injection attempts in form fields.
 *
 * @param array $fields Array of form fields to check
 * @return bool True if injection attempt detected, false otherwise
 */
function nodoss_check_header_injection(array $fields): bool {
    $injection = false;
    foreach ($fields as $field) {
        if (preg_match('/%0A|%0D|\r|\n/', $field)) {
            $injection = true;
            break;
        }
    }
    return $injection;
}

/**
 * Pre-process input to sanitize and normalize it.
 *
 * @param string $input The input string to process
 * @return string The processed input
 */
function nodoss_pre_process_input($input) {
    $input = str_replace('https://', '', $input);
    $input = str_replace('http://', '', $input);
    $input = str_replace(' ', '', $input);
    $input = str_replace('\'+\'', '', $input);
    $input = str_replace('"+"', '', $input);
    $input = str_replace('\\', '/', $input);
    $input = urldecode($input);
    return $input;
}

/**
 * Get the type of attack detected.
 *
 * @param bool $sqli SQL injection flag
 * @param bool $cmd Command injection flag
 * @param bool $dir Directory traversal flag
 * @return string The type of attack detected
 */
function nodoss_text_from_blocked(bool $sqli, bool $cmd, bool $dir): string {
    if ($sqli) {
        return 'SQL Injection';
    }
    if ($cmd) {
        return 'CMD Injection';
    }
    if ($dir) {
        return 'Directory Transversal';
    }
    return 'unknown';
}

/**
 * Detect SQL injection patterns in URL parameters.
 *
 * @param string $input The input string to check
 * @return bool True if SQL injection detected, false otherwise
 */
function nodoss_detect_sql_injection_url(string $input): bool {
    $pattern = '/(\'|%27|--|\#|\/\*)[^\n]*((information|into|from|select|union|where|and|or|\|\||&|\&\&)[^\n]*)+/ix';
    $input = nodoss_pre_process_input($input);
    return (bool) preg_match($pattern, $input);
}

/**
 * Detect command injection patterns.
 *
 * @param string $input The input string to check
 * @return bool True if command injection detected, false otherwise
 */
function nodoss_detect_cmd_injection(string $input): bool {
    $pattern_linux = '/;\s*(?:\/\*.*?\*\/\s*)?(?:\|\||&&)?\s*[\n\r]*|`.*?`|;?\s*shutdown\s*(?:-r|-h)?\s*(?:now|0)?\b/i';
    $pattern_windows = '/(\b(?:exec|xp_cmdshell|sp_executesql)\b|\|\||&&|\bping\b)|\s*\bnet\b\s*(?:user|group|localgroup)\b/i';

    $input = nodoss_pre_process_input($input);

    return (bool) (preg_match($pattern_linux, $input) || preg_match($pattern_windows, $input));
}

/**
 * Detect directory traversal patterns.
 *
 * @param string $input The input string to check
 * @return bool True if directory traversal detected, false otherwise
 */
function nodoss_detect_transversal_directory(string $input): bool {
    $regex = '#\.{2};?\/|\/var\/|\/usr\/|\/etc\/#';
    $input = nodoss_pre_process_input($input);
    return (bool) preg_match($regex, $input);
}

/**
 * Floating Point DoS Protection Class
 */
class FrontiersFloatingPointNoDosProtection
{
    /**
     * Recursively serialize data for pattern checking
     */
    private static function serializeData($data): string
    {
        if (is_array($data) || $data instanceof Traversable) {
            $result = '';
            foreach ($data as $key => $value) {
                $result .= (string)$key . self::serializeData($value);
            }
            return $result;
        }
        return (string)$data;
    }

    /**
     * Check for floating point DoS attack pattern
     */
    public static function protect()
    {
        $allVars = '';

        // Check all superglobals
        foreach (['_GET', '_POST', '_COOKIE'] as $global) {
            if (!empty($GLOBALS[$global])) {
                $allVars .= '|' . self::serializeData($GLOBALS[$global]);
            }
        }

        // Check for the attack pattern
        if ($allVars !== '' && strpos(str_replace('.', '', $allVars), '22250738585072011') !== false) {
            self::handleAttack();
        }
    }

    /**
     * Handle the attack by terminating execution
     */
    private static function handleAttack()
    {
        http_response_code(422);
        header('Content-Type: text/html; charset=UTF-8');
        die('<h1>422 Unprocessable Entity</h1><p>Script interrupted due to floating point DoS attack.</p>');
    }
}

// Initialize protection
FrontiersFloatingPointNoDosProtection::protect();