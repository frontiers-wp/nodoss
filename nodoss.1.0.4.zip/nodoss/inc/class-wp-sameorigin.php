<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly
/**
 * NoDoss Same-Origin Frame Protection
 *
 * Prevents clickjacking and iframe embedding from different origins
 */
class NoDossFrontiersSameOriginFrame
{
    /**
     * Initialize the class
     */
    public function __construct()
    {
        $this->load_dependencies();
        $this->setup_hooks();
    }

    /**
     * Load required dependencies
     */
    private function load_dependencies()
    {
        require_once plugin_dir_path(dirname(__FILE__)) . 'inc/class-wp-blank-target-vulnerability.php';
    }

    /**
     * Setup WordPress hooks
     */
    private function setup_hooks()
    {
        // Security header
        add_action('template_redirect', [$this, 'nodoss_send_frame_options_header']);

        // Frame busting techniques
        add_action('wp_head', [$this, 'nodoss_break_out_of_frames'], 0);
        add_action('wp_enqueue_scripts', [$this, 'nodoss_modern_frame_buster']);
        add_action('admin_print_scripts', [$this, 'nodoss_admin_frame_buster'], 0);
    }

    /**
     * Send X-Frame-Options header to prevent clickjacking
     */
    public function nodoss_send_frame_options_header()
    {
        @header('X-Frame-Options: SAMEORIGIN');
    }

    /**
     * Legacy method to break out of frames using JavaScript
     */
    public function nodoss_break_out_of_frames()
    {
        if (!is_preview() && !is_customize_preview()) {
        echo "\n<script type=\"text/javascript\">";
        echo "\n<!--";
        echo "\nif (parent.frames.length > 0) { parent.location.href = location.href; }";
        echo "\n-->";
        echo "\n</script>\n\n";
        }
    }

    /**
     * Modern iframe buster using WordPress script handling
     */
    public function nodoss_modern_frame_buster()
    {
        wp_enqueue_script('nodoss_prevent_iframe_embed');

        // Add the iframe buster script
        add_action('wp_print_footer_scripts', [$this, 'nodoss_prevent_iframe_embed']);
    }

    /**
     * Prevent iframe embedding
     */
    public function nodoss_prevent_iframe_embed()
    {
        ?>
        <script type="text/javascript">
            if (self == top) {
                var theBody = document.getElementsByTagName("body")[0];
                theBody.style.display = "block";
            } else {
                top.location = self.location;
            }
        </script>
        <?php
    }

    /**
     * Frame buster for admin area
     */
    public function nodoss_admin_frame_buster()
    {
        ?>
        <script type="text/javascript">
            (function(){
                if(window.top != window.self){
                    window.top.location = window.self.location;
                }
            })();
        </script>
        <?php
    }
}

// Initialize the class
new NoDossFrontiersSameOriginFrame();