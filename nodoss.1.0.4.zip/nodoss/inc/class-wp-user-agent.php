<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Blocks requests from bad user agents and darknet spam comments
 */
class NoDossAgentSecurity {
    /**
     * Patterns for detecting malicious user agents
     *
     * @var array
     */
    private static $badUserAgentPatterns = [
        '/(\<|\>|\'|\$x0|\%0A|\%0D|\%27|\%3C|\%3E|\%00|\+select|\+union|\&lt)/i',
        '/(binlar|casper|checkprivacy|cmsworldmap|comodo|curious|diavol|doco)/i',
        '/(dotbot|feedfinder|flicky|ia_archiver|kmccrew|libwww|nutch)/i',
        '/(planetwork|purebot|pycurl|skygrid|sucker|turnit|vikspid|zmeu|zune)/i',
    ];

    /**
     * Patterns for detecting darknet spam
     *
     * @var array
     */
    private static $darknetSpamPatterns = [
        'dark net', 'dark web', 'dark market', 'darkmarket', 'darknet',
        'drug store', 'nexus market', 'nexus link', 'nexus url',
        'nexus dark', 'nexusdark', 'nexus onion'
    ];

    /**
     * Checks if a user agent is malicious
     *
     * @param string $userAgent The user agent string to check
     * @return bool True if the user agent is malicious, false otherwise
     */
    public static function isBadUserAgent(string $userAgent): bool {
        foreach (self::$badUserAgentPatterns as $pattern) {
            if (preg_match($pattern, $userAgent)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Blocks darknet spam in POST requests
     *
     * @param array $request The request array (typically $_REQUEST or parsed request)
     */
    public static function blockDarknetSpam(array $request) {
        if (isset($request['method']) &&
            strtoupper($request['method']) === 'POST' &&
            isset($request['body']['comment'])) {

            $comment = $request['body']['comment'];

            foreach (self::$darknetSpamPatterns as $pattern) {
                if (stripos($comment, $pattern) !== false) {
                    http_response_code(403);
                    header('Content-Type: text/plain');
                    die('Forbidden');
                }
            }
        }
    }
}

// For comment spam checking (in your request handler):
// NoDossSecurity::blockDarknetSpam($yourRequestArray);
?>