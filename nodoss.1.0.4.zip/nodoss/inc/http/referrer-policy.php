<?php
// Referrer-Policy: no-referrer
// Referrer-Policy: no-referrer-when-downgrade
// Referrer-Policy: origin
// Referrer-Policy: origin-when-cross-origin
// Referrer-Policy: same-origin
// Referrer-Policy: strict-origin
// Referrer-Policy: strict-origin-when-cross-origin
// Referrer-Policy: unsafe-url
/** NoDoss - Referrer-Policy header */
function nodoss_referrer_policy_headers() {
    header( 'Referrer-Policy: strict-origin-when-cross-origin ');
}
add_action( 'send_headers', 'nodoss_referrer_policy_headers' );