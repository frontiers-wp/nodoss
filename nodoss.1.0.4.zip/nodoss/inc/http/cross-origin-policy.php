<?php // Cross Origin policy header
function nodoss_cross_origin_policy_headers() {
    /** Cross-Origin-Opener-Policy */
    header( 'Cross-Origin-Opener-Policy: same-origin-allow-popups ');
    /** Cross-Origin-Embedder-Policy */
    header( 'Cross-Origin-Embedder-Policy: require-corp ');
    /** Cross-Origin-Resource-Policy */
    header( 'Cross-Origin-Resource-Policy: same-site'); // header( 'Cross-Origin-Resource-Policy: cross-origin ') 
}
add_action( 'send_headers', 'nodoss_cross_origin_policy_headers' );