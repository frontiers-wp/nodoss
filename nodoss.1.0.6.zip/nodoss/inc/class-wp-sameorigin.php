<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * NoDoss Same-Origin Frame Protection
 *
 * Prevents clickjacking and iframe embedding from different origins
 */
class NoDossSameOriginFrame
{
    /**
     * Initialize the class
     */
    public function __construct()
    {
        $this->setup_hooks();
    }

    /**
     * Setup WordPress hooks
     */
    private function setup_hooks()
    {
        // Send X-Frame-Options header
        add_action('template_redirect', [$this, 'send_frame_options_header']);

        // Modern iframe buster
        add_action('wp_enqueue_scripts', [$this, 'prevent_iframe_embed'], 10);

        // nodoss_blank_target_vulnerability
        add_action('wp_enqueue_scripts', [$this, 'blank_target_vulnerability'], 10);

        // Enqueue same as origin
        // add_action('wp_head', [$this, 'injectContextMenuProtectionCss'], 99);
    }

    /**
     * Send X-Frame-Options header to prevent clickjacking
     */
    public function send_frame_options_header()
    {
        header('X-Frame-Options: SAMEORIGIN');
    }
    
    /**
     * Register and enqueue the prevent iframe embed script
     */
    public function prevent_iframe_embed()
    {
        // Register the script with dependencies and set to load in the footer
        wp_register_script(
            'same-origin-frame',
            plugins_url('/assets/js/js/same.origin.frame.js', __FILE__),
            array(),
            '1.0',
            true
        );

        // Enqueue the script
        wp_enqueue_script('same-origin-frame');
    }

    /**
     * Register and enqueue the prevent iframe embed script
     */
    public function blank_target_vulnerability()
    {
        // Register the script with dependencies and set to load in the footer
        wp_register_script(
            'blank-target-vulnerability',
            plugins_url('/assets/js/js/blank.target.vulnerability.js', __FILE__),
            array(),
            '1.0',
            true
        );

        // Enqueue the script
        wp_enqueue_script('blank-target-vulnerability');
    }

}

// Initialize the class
new NoDossSameOriginFrame();
