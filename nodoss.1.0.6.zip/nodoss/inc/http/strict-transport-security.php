<?php
/**
 * Set the HSTS header
 */
function nodoss_sec_hsts_header()
{
    // 2 years in seconds (63072000)
    $maxAge = 63072000;

    header(
        sprintf(
            'Strict-Transport-Security: max-age=%d; includeSubDomains; preload;',
            $maxAge
        )
    );
}
add_action('send_headers', 'nodoss_sec_hsts_header');