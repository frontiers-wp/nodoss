<?php defined('ABSPATH') or die("you do not have access to this page!");
/**
 * Remove rsd_link from filters- link rel="EditURI"
 */
add_action('nodoss_wp_head', function(){
    // Remove rsd_link from filters- link rel="EditURI"
    remove_action('wp_head', 'rsd_link');
    remove_action('xmlrpc_rsd_apis', 'rest_output_rsd');
    // Windows Live Writer
    // <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="/wp-includes/wlwmanifest.xml" /> 
    remove_action('wp_head', 'wlwmanifest_link');
}, 9);

// Block specific REST API endpoints
add_filter('rest_endpoints', function ($endpoints) {
    // List of blocked endpoints
    $blocked_endpoints = [
        '/wp/v2/users',
        '/wp/v2/users/(?P<id>[\d]+)'
    ];

    foreach ($blocked_endpoints as $endpoint) {
        if (isset($endpoints[$endpoint])) {
            unset($endpoints[$endpoint]);
        }
    }

    return $endpoints;
});

// Disable XML-RPC completely
add_filter('xmlrpc_enabled', '__return_false');
// Disable system.multicall and other XML-RPC methods
add_filter('xmlrpc_methods', function ($methods) {
    unset($methods['system.multicall']);
    unset($methods['system.listMethods']);
    unset($methods['system.getCapabilities']);
    unset($methods['mt.getTrackbackPings']);
    unset($methods['mt.publishPost']);
    unset($methods['wp.getUsersBlogs']);
    unset($methods['pingback.ping']);
    unset($methods['pingback.extensions.getPingbacks']);
    return $methods;
});

/**
 * Disable X-Pingback HTTP Header.
 */
add_filter( 'nodoss_wp_headers', function($headers, $wp_query){
    if(isset($headers['X-Pingback'])){
        unset($headers['X-Pingback']);
    }
    return $headers;
}, 11, 2);

/**
 * Remove pingback from head (link rel="pingback")
 * Disable Ping tracks incl ajax script
 */
function nodoss_pingback_url( $buffer ) {
    # If in the admin panel, don't run
    if ( is_admin() && ( ! defined( 'DOING_AJAX' ) || ! DOING_AJAX ) ) {
        return $buffer;
    }
    $buffer = preg_replace( '/(<link.*?rel=("|\')pingback("|\').*?href=("|\')(.*?)("|\')(.*?)?\/?>|<link.*?href=("|\')(.*?)("|\').*?rel=("|\')pingback("|\')(.*?)?\/?>)/i', '', $buffer );
    return $buffer;
}

/**
 * Disable Ping
 */
add_filter( 'rewrite_rules_array', function( $rules ) {
    foreach( $rules as $rule => $rewrite ) {
        if( preg_match( '/trackback\/\?\$$/i', $rule ) ) {
            unset( $rules[$rule] );
        }
    }
    return $rules;
});

// Hijack pingback_url for get_bloginfo (<link rel="pingback" />).
add_filter('nodoss_bloginfo_url', function($output, $property){
    return ($property == 'pingback_url') ? null : $output;
}, 11, 2);


/**
 * Disable XML-RPC ping
 */
function nodoss_disable_xmlrpc_request() {
	if ( current_user_can('NODOSS_XMLRPC_REQUEST') )
		define('NODOSS_XMLRPC_REQUEST', false );
}

add_action( 'admin_init', 'nodoss_disable_xmlrpc_request' );
add_filter( 'pre_update_option_enable_xmlrpc', '__return_false' );
add_filter( 'pings_open', '__return_false', 10, 2 );