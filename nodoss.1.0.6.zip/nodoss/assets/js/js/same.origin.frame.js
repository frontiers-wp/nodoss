/**
 * NoDoss Same-Origin Frame Protection
 *
 * Prevents clickjacking and iframe embedding from different origins
 */
class NoDossSameOriginFrame {
    /**
     * Initialize the class
     */
    constructor() {
        this.setupHooks();
    }

    /**
     * Setup event listeners and hooks
     */
    setupHooks() {
        // Frame busting techniques
        document.addEventListener('DOMContentLoaded', this.nodossBreakOutOfFrames.bind(this));
        this.nodossModernFrameBuster();
        this.nodossAdminFrameBuster();
        this.nodossDisableRightClick();
    }

    /**
     * Legacy method to break out of frames using JavaScript
     */
    nodossBreakOutOfFrames() {
        // Check if this is a preview or customize preview WordPress
        const isPreview = window.location.href.includes('preview=true') ||
                         window.location.href.includes('wp-customize=on');

        if (!isPreview) {
            const script = document.createElement('script');
            script.type = 'text/javascript';
            script.text = `
                if (parent.frames.length > 0) {
                    parent.location.href = location.href;
                }
            `;
            document.head.appendChild(script);
        }
    }

    /**
     * Modern iframe buster
     */
    nodossModernFrameBuster() {
        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.text = `
            if (self == top) {
                var theBody = document.getElementsByTagName("body")[0];
                theBody.style.display = "block";
            } else {
                top.location = self.location;
            }
        `;
        document.body.appendChild(script);
    }

    /**
     * Frame buster for admin area
     */
    nodossAdminFrameBuster() {
        const isAdmin = window.location.href.includes('/wp-admin/');

        if (isAdmin) {
            const script = document.createElement('script');
            script.type = 'text/javascript';
            script.text = `
                (function(){
                    if(window.top != window.self){
                        window.top.location = window.self.location;
                    }
                })();
            `;
            document.head.appendChild(script);
        }
    }

    /**
     * Outputs JavaScript to disable right-click context menu
     */
    nodossDisableRightClick() {
        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.text = `
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });
        `;
        document.body.appendChild(script);
    }
}

// Initialize the class
new NoDossSameOriginFrame();