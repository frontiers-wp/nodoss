<?php
// Suppress ServerSignature and ServerTokens on Apache and Nginx HTTP-Server.
if (function_exists('header_remove')) {
    header_remove('X-Powered-By'); // Remove X-Powered-By header
} else {
    // Set expose_php to off in php.ini
    ini_set('expose_php', 'off');
    // Disable directory listing
    ini_set('Options -Indexes', 'off');
}

/**
 * Hide FastCGI headers if the function exists.
 */
function nodossFastcgiHideHeader() {
    if (function_exists('fastcgiHideHeader')) {
        fastcgiHideHeader(0);
    }
}