<?php defined('ABSPATH') or die('Sorry dude!');
/**
 * QUICK FIX Heartbeat
 */
add_action( 'admin_init', function() {
   register_setting( 'general', 'custom_heartbeat_interval', 'intval' );
   add_settings_field( 'custom_heartbeat_interval', 'Heartbeat Interval', function() {
       $interval = get_option( 'custom_heartbeat_interval', 240 );
       echo "<input type='number' name='custom_heartbeat_interval' value='".absint($interval)."' min='15' max='240' /> seconds";
   }, 'general' );
});
 
add_filter( 'heartbeat_settings', function( $settings ) {
   $settings['interval'] = get_option( 'custom_heartbeat_interval', 240 );
   return $settings;
});
