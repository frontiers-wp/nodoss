=== NoDoss ===
Plugin URI: https://wordpress.org/plugins/nodoss
Donate link: https://paypal.me/EBekedam
Contributors: frontiers
Author URI: https://github.com/frontiers-wp/nodoss
Tags: security
Description: Lightweight Security plugin hacking againts attacks.
Requires at least: 5.0
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Stop bots, pingbacks, brute force hacking, script jacking, Iframe XSS attacks, CSRF Proctection, Insecure requests, invalid unwanted user edits. 

== Description ==

Pre-set Security Headers: 

=cross origin policy=
=cross origin resource sharing=
=referrer-policy=
=x content-type-options =
=x permitted cross domain policies = 

== Installation ==

1. Upload 'nodoss.zip' to the '/wp-content/plugins/' directory
2. Extract the Plugin to a `nodoss` Folder
3. Activate the plugin through the 'Plugins' menu in WordPress
4. General Settings - Heartbeat <15> <240> Interval seconds 

== OR ==

1. Go to `Plugins` in the Admin menu
2. Click on the button `Add new`
3. Search for nodoss` and click 'Install Now' or click on the `upload` link to upload `nodoss.zip`
4. Click on `Activate plugin`
5. General Settings - Heartbeat <15> <240> Interval seconds 

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.


== Changelog ==

= 1.0.0: November 01, 2025 =
* Birthday of nodoss
