<?php
/**
 * Quick Fix Heartbeat Customization.
 *
 * @package Frontiers\NoDossApiSecurity
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Sorry dude!' );
}

/**
 * Register Heartbeat settings in the WordPress General Settings section.
 */
add_action( 'admin_init', function () {
	// Register the setting with explicit argument validation configuration.
	register_setting(
		'general',
		'nodoss_aj_heartbeat_interval',
		array(
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'default'           => 240,
		)
	);

	// Add the settings field to Settings -> General.
	add_settings_field(
		'nodoss_aj_heartbeat_interval',
		__( 'Heartbeat Interval', 'nodoss' ),
		function () {
			$interval = get_option( 'nodoss_aj_heartbeat_interval', 240 );
			?>
			<input type="number" name="nodoss_aj_heartbeat_interval" value="<?php echo esc_attr( absint( $interval ) ); ?>" min="15" max="240" /> 
			<?php
			echo esc_html__( 'seconds', 'nodoss' );
		},
		'general'
	);
} );

/**
 * Apply the saved setting to the WordPress Heartbeat API.
 *
 * @param array<string, mixed> $settings Default heartbeat configuration options.
 * @return array<string, mixed> Modified heartbeat configuration options.
 */
add_filter( 'heartbeat_settings', function ( array $settings ): array {
	$interval = get_option( 'nodoss_aj_heartbeat_interval', 240 );
	
	// Validate setting is inside legal WordPress boundary constraints (15 to 120/240 seconds).
	$settings['interval'] = max( 15, min( 240, absint( $interval ) ) );
	
	return $settings;
} );