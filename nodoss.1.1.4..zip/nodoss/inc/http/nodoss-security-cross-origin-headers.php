<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * NoDoss - Complete Unified Security & Cross-Origin Headers
 * Combines all deployment-ready security headers into a single WordPress hook.
 */
function nodoss_add_complete_security_headers() {
    // --- Origin & Isolation Headers ---
    header( 'Origin-Agent-Cluster: ?1' );
    header( 'Cross-Origin-Opener-Policy: same-origin-allow-popups' );
    header( 'Cross-Origin-Embedder-Policy: cross-origin' );
    // Use 'same-site' only if your frontend and WP backend share the exact same root domain.   
    header( 'Cross-Origin-Resource-Policy: cross-origin' );  

    // --- Content & Privacy Headers ---
    header( 'Content-Security-Policy: upgrade-insecure-requests' );
    header( 'Referrer-Policy: strict-origin-when-cross-origin' );
    header( 'X-Content-Type-Options: nosniff' );

    // --- Transport Security (HSTS) ---
    // Production configured: 2 years (63072000s), fully preloaded, covering all subdomains.
    header( 'Strict-Transport-Security: max-age=63072000; includeSubDomains; preload' );

    // --- Legacy Protections ---
    header( 'X-Permitted-Cross-Domain-Policies: master-only' );
}
add_action( 'send_headers', 'nodoss_add_complete_security_headers' );