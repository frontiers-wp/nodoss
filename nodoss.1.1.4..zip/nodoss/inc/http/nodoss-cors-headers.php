<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
/**
 * Add HTTPS CORS Headers
 */
function nodoss_add_cors_headers() {
    // Validate the incoming origin
    if ( isset( $_SERVER['HTTP_ORIGIN'] ) ) {
        // Fixed: added missing closing parenthesis for wp_unslash
        $origin = esc_url_raw( wp_unslash( $_SERVER['HTTP_ORIGIN'] ) );
        
        if ( in_array( $origin, $allowed_origins, true ) ) {
            header( "Access-Control-Allow-Origin: " . $origin );
        }
    }

    // Allow Credentials (Sessions, Cookies, and Auth Headers)
    header( "Access-Control-Allow-Credentials: true" );
    // Combined Allowed Headers (Merged to prevent overwriting)
    header( "Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Custom-Header, Upgrade-Insecure-Requests" );
    // Allowed HTTP Methods
    header( "Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS" );
    // Exposed Headers (Headers the frontend JS is allowed to read)
    header( "Access-Control-Expose-Headers: Content-Length, X-JSON" );
    // Preflight Cache Duration (24 hours in seconds)
    header( "Access-Control-Max-Age: 86400" );
    // Handle preflight (OPTIONS) requests immediately
    if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'OPTIONS' === $_SERVER['REQUEST_METHOD'] ) {
        status_header( 200 );
        exit;
    }
}
add_action( 'send_headers', 'nodoss_add_cors_headers' );