<?php
/**
 * Removes WordPress version footprints safely.
 *
 * @package Nodoss\Frontiers\Security
 */
namespace Nodoss\Frontiers\Security;

if (!defined('ABSPATH')) {
    die();
}

/**
 * Clean up version strings from scripts and styles query parameters.
 * 
 * Removes the 'ver' argument completely from internal assets to protect privacy.
 *
 * @param string $src The source URL of the asset.
 * @return string The cleaned source URL.
 */
function remove_asset_version(string $src): string
{
    // Ensure we only modify internal URLs to avoid breaking external CDNs
    if (str_contains($src, 'ver=')) {
        return remove_query_arg('ver', $src);
    }
    
    return $src;
}

/**
 * Initializes security hooks to strip version numbers.
 */
function initialize_version_removal(): void
{
    // Remove the generator meta tag from head and RSS feeds
    remove_action('wp_head', 'wp_generator');
    add_filter('the_generator', '__return_empty_string');

    // Remove version strings from enqueued scripts and styles
    add_filter('script_loader_src', __NAMESPACE__ . '\\remove_asset_version', 15);
    add_filter('style_loader_src', __NAMESPACE__ . '\\remove_asset_version', 15);
}

// Hook the initialization into WordPress init
add_action('init', __NAMESPACE__ . '\\initialize_version_removal');
