<?php
/**
 * Security enhancements to prevent user enumeration and restrict API access
 */
if (!defined('IS_ADMIN')) {
    define('IS_ADMIN', is_admin());
}

/**
 * Checks if the current request is attempting author enumeration
 *
 * @return bool True if it's an author enumeration attempt
 */
function is_author_enum_request(): bool {
    return isset($_GET['author']) && is_numeric($_GET['author']);
}

/**
 * Modifies query variables to prevent author enumeration
 *
 * @param array $vars The query variables
 * @return array The modified query variables
 */
function nodoss_remove_author_from_query_vars(array $vars): array {
    if (isset($vars['author'])) {
        unset($vars['author']);
    }
    return $vars;
}

/**
 * Prevents author enumeration via redirects
 *
 * @param string $redirect The redirect URL
 * @param string $request The original request
 * @return string The modified redirect URL
 */
function nodoss_remove_author_from_redirects(string $redirect, string $request): string {
    if (!IS_ADMIN && is_author_enum_request()) {
        $_GET = nodoss_remove_author_from_query_vars($_GET);
    }
    return $redirect;
}
add_filter('redirect_canonical', 'nodoss_remove_author_from_redirects', 10, 2);

/**
 * Removes REST API endpoints for non-logged-in users
 */
function nodoss_remove_api_endpoints_for_guests(): void {
    if (!is_user_logged_in()) {
        // Remove WordPress endpoints
        remove_action('rest_api_init', 'create_initial_rest_routes', 99);
        remove_action('rest_api_init', 'wp_oembed_add_discovery_links', 99);

        // Remove WooCommerce endpoints if WC exists
        if (class_exists('WooCommerce')) {
            remove_action('rest_api_init', [WC()->api, 'register_rest_routes'], 10);
        }
    }
}
add_action('init', 'nodoss_remove_api_endpoints_for_guests', 15);

/**
 * Disables REST API for non-authenticated users
 *
 * @param mixed $user The user object or false if not authenticated
 * @return mixed The user object or false
 */
function nodoss_disable_rest_for_guests($user) {
    if (!$user) {
        add_filter('rest_enabled', '__return_false');
        add_filter('rest_jsonp_enabled', '__return_false');
    }
    return $user;
}
add_filter('determine_current_user', 'nodoss_disable_rest_for_guests', 50);

/**
 * Removes author class from comment classes to prevent user enumeration
 *
 * @param array $classes Array of comment classes
 * @return array Filtered array of comment classes
 */
function nodoss_remove_comment_author_classes(array $classes): array {
    return array_filter($classes, function($class) {
        return strpos($class, 'comment-author-') === false;
    });
}
add_filter('comment_class', 'nodoss_remove_comment_author_classes');
