<?php defined('ABSPATH') or die('Sorry dude!');
/**
 * Check for header injection attempts in form fields.
 *
 * @param array $fields Array of form fields to check
 * @return bool True if injection attempt detected, false otherwise
 */
function nodoss_check_header_injection(array $fields): bool {
    $injection = false;
    foreach ($fields as $field) {
        if (preg_match('/%0A|%0D|\r|\n/', $field)) {
            $injection = true;
            break;
        }
    }
    return $injection;
}

/**
 * Pre-process input to sanitize and normalize it.
 *
 * @param string $input The input string to process
 * @return string The processed input
 */
function nodoss_pre_process_input($input) {
    $input = str_replace('https://', '', $input);
    $input = str_replace('http://', '', $input);
    $input = str_replace(' ', '', $input);
    $input = str_replace('\'+\'', '', $input);
    $input = str_replace('"+"', '', $input);
    $input = str_replace('\\', '/', $input);
    $input = urldecode($input);
    return $input;
}

/**
 * Get the type of attack detected.
 *
 * @param bool $sqli SQL injection flag
 * @param bool $cmd Command injection flag
 * @param bool $dir Directory traversal flag
 * @return string The type of attack detected
 */
function nodoss_text_from_blocked(bool $sqli, bool $cmd, bool $dir): string {
    if ($sqli) {
        return 'SQL Injection';
    }
    if ($cmd) {
        return 'CMD Injection';
    }
    if ($dir) {
        return 'Directory Transversal';
    }
    return 'unknown';
}

/**
 * Detect SQL injection patterns in URL parameters.
 *
 * @param string $input The input string to check
 * @return bool True if SQL injection detected, false otherwise
 */
function nodoss_detect_sql_injection_url(string $input): bool {
    $pattern = '/(\'|%27|--|\#|\/\*)[^\n]*((information|into|from|select|union|where|and|or|\|\||&|\&\&)[^\n]*)+/ix';
    $input = nodoss_pre_process_input($input);
    return (bool) preg_match($pattern, $input);
}

/**
 * Detect command injection patterns.
 *
 * @param string $input The input string to check
 * @return bool True if command injection detected, false otherwise
 */
function nodoss_detect_cmd_injection(string $input): bool {
    $pattern_linux = '/;\s*(?:\/\*.*?\*\/\s*)?(?:\|\||&&)?\s*[\n\r]*|`.*?`|;?\s*shutdown\s*(?:-r|-h)?\s*(?:now|0)?\b/i';
    $pattern_windows = '/(\b(?:exec|xp_cmdshell|sp_executesql)\b|\|\||&&|\bping\b)|\s*\bnet\b\s*(?:user|group|localgroup)\b/i';

    $input = nodoss_pre_process_input($input);

    return (bool) (preg_match($pattern_linux, $input) || preg_match($pattern_windows, $input));
}

/**
 * Detect directory traversal patterns.
 *
 * @param string $input The input string to check
 * @return bool True if directory traversal detected, false otherwise
 */
function nodoss_detect_transversal_directory(string $input): bool {
    $regex = '#\.{2};?\/|\/var\/|\/usr\/|\/etc\/#';
    $input = nodoss_pre_process_input($input);
    return (bool) preg_match($regex, $input);
}

/**
 * Floating Point DoS Protection Class
 */
class FloatingPointDosProtection
{
    /**
     * Recursively serialize data for pattern checking
     */
    private static function serializeData($data): string
    {
        if (is_array($data) || $data instanceof Traversable) {
            $result = '';
            foreach ($data as $key => $value) {
                $result .= (string)$key . self::serializeData($value);
            }
            return $result;
        }
        return (string)$data;
    }

    /**
     * Check for floating point DoS attack pattern
     */
    public static function protect(): void
    {
        $allVars = '';

        // Check all superglobals
        foreach (['_GET', '_POST', '_COOKIE'] as $global) {
            if (!empty($GLOBALS[$global])) {
                $allVars .= '|' . self::serializeData($GLOBALS[$global]);
            }
        }

        // Check for the attack pattern
        if ($allVars !== '' && strpos(str_replace('.', '', $allVars), '22250738585072011') !== false) {
            self::handleAttack();
        }
    }

    /**
     * Handle the attack by terminating execution
     */
    private static function handleAttack(): void
    {
        http_response_code(422);
        header('Content-Type: text/html; charset=UTF-8');
        die('<h1>422 Unprocessable Entity</h1><p>Script interrupted due to floating point DoS attack.</p>');
    }
}

// Initialize protection
FloatingPointDosProtection::protect();