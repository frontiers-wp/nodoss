<?php
// Remove URL field from WordPress comment form
add_filter('comment_form_field_url', '__return_false');
add_filter('comment_form_default_fields', 'nodoss_website_remove');

/**
 * Remove website field from comment form
 *
 * @param array $fields The default comment form fields
 * @return array Modified comment form fields
 */
function nodoss_website_remove($fields) {
    if (isset($fields['url'])) {
        unset($fields['url']);
    }
    return $fields;
}

/**
 * Generate and add CSRF tokens to the comment form
 *
 * This function creates a secure CSRF token by combining a WordPress nonce
 * with a cryptographically secure random value, then signs it with HMAC-SHA256.
 */
function nodoss_add_comment_form_csrf() {
    // Generate a WordPress nonce
    $wp_nonce = wp_create_nonce('comment_form_csrf');

    // Generate a secure random token
    $build_id = 'comment-form-csrf-' . base64_encode(random_bytes(32));

    // Create the CSRF token
    $key = SECURE_AUTH_KEY;
    $data = $build_id . $wp_nonce;
    $signature = hash_hmac('sha256', $data, $key, true);
    $csrf_token = base64_encode($signature);

    // Output the hidden fields
    echo '<input type="hidden" name="build_id" value="' . esc_attr($build_id) . '">';
    echo '<input type="hidden" name="wp_nonce" value="' . esc_attr($wp_nonce) . '">';
    echo '<input type="hidden" name="csrf_token" value="' . esc_attr($csrf_token) . '">';
}

/**
 * Validate CSRF tokens when a comment is submitted
 *
 * @param array $form_data The submitted form data
 * @return bool True if validation passes, false otherwise
 */
function validate_comment_csrf($form_data) {
    // Check if all required fields are present
    if (!isset($form_data['build_id']) || !isset($form_data['wp_nonce']) || !isset($form_data['csrf_token'])) {
        return false;
    }

    // Check if the build_id has the correct prefix
    if (strpos($form_data['build_id'], 'comment-form-csrf-') !== 0) {
        return false;
    }

    // Verify the WordPress nonce
    if (!wp_verify_nonce($form_data['wp_nonce'], 'comment_form_csrf')) {
        return false;
    }

    // Verify the CSRF token
    $key = SECURE_AUTH_KEY;
    $data = $form_data['build_id'] . $form_data['wp_nonce'];
    $signature = hash_hmac('sha256', $data, $key, true);
    $expected_token = base64_encode($signature);

    return $expected_token === $form_data['csrf_token'];
}

// Add CSRF tokens to the form
add_action('comment_form_after_fields', 'nodoss_add_comment_form_csrf');

// Validate CSRF tokens when the form is submitted
add_action('pre_comment_on_post', function($comment_post_ID) {
    // Get the form data
    $form_data = $_POST;

    // Validate the CSRF tokens
    $is_valid = validate_comment_csrf($form_data);

    if (!$is_valid) {
        // Show an error message and prevent form submission
        wp_die('Comment submission failed due to security validation failures. Please refresh the page and try again.');
    }
});