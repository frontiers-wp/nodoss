<?php // X-Permitted-Cross-Domain-Policies 
function nodoss_cdp_master_only_headers() {
    /** Master Only */
    header( 'X-Permitted-Cross-Domain-Policies: master-only ');
}
add_action( 'send_headers', 'nodoss_cdp_master_only_headers' );