<?php
// Check if the REDIRECT_URL server variable exists and perform sitemap URL redirection
if (isset($_SERVER['REDIRECT_URL'])) {
    $url = $_SERVER['REDIRECT_URL'];

    // Case-insensitive regex to match various sitemap URL patterns
    if (preg_match('%(?i)(?<!^)\/(.*)?sitemap(.*)?\.(htm|html|xml)(\\.gz)?%', $url, $matches)) {
        // Determine if the original request was for a gzipped version
        $gzSuffix = $matches[4] ?? '';

        // Send 301 permanent redirect to canonical sitemap URL
        header('HTTP/1.1 301 Moved Permanently', true, 301);
        header('Location: /sitemap.xml' . $gzSuffix, true, 301);
        exit;
    }
}

/**
 * Blocks user enumeration via WordPress sitemap.
 * Covers both standard and URL-encoded hyphens (%2d).
 *
 * @param string|null $redirect The redirect URL (unused in this context).
 * @param string      $request  The requested URL path.
 * @return string|null Returns null to terminate execution if enumeration is detected.
 */
function nosdoss_wpmap_enum(?string $redirect, string $request): ?string {
    if (preg_match('%(?i)(wp-sitemap-users-[0-9]+\\.xml)%', $request)) {
        // Terminate execution silently to block enumeration
        http_response_code(403);
        exit;
    }
    return $redirect;
}
?>